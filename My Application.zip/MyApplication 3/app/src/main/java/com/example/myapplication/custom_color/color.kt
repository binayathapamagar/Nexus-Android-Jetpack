package com.example.myapplication.custom_color

import androidx.compose.ui.graphics.Color

object color {
    val White = Color(0xFFFFFFFF)
    val Black = Color(0xFF000000)
    val Gray = Color(0xFF888888)
}